package adapters;

/**
 * @author: Duck Nguyen
 * @date: 03/21/2018
 *
 * Line adapter is the adapter needed for Line to be compatible with SavedShapes
 */

import drawing.IShape;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import shapes.Line;

public class LineAdapter implements IShape
{
    private Line line;
    private Color color;

    /**
     * Constructor for the adapter
     * @param lineToDraw - line object as selected by user
     */
    public LineAdapter(Line lineToDraw)
    {
        this.line = lineToDraw;
        this.color = lineToDraw.getColor();
    }

    /**
     * Setting the thickness of shape's stroke
     *
     * @param value - 1-10 of thickness level
     * @return Shape with selected stroke thickness
     */
    @Override
    public IShape setThickness(double value)
    {
        line.setThickness(value);
        return this;
    }

    /**
     * Setting the color of shape
     *
     * @param value - selected color
     * @return Shape with selected color value
     */
    @Override
    public IShape setColor(Color value)
    {
        color = value;
        return this;
    }

    /**
     * Toggle filling shape with color
     *
     * @param value - selected fill option
     * @return Shape with selected fill option
     */
    @Override
    public IShape setFilled(boolean value)
    {
        return this;
    }

    /**
     * Retrieve selected x coordinate to draw on canvas
     *
     * @return value of x
     */
    @Override
    public double getXCoordinate()
    {
        return line.getX();
    }

    /**
     * Retrieve selected y coordinate to draw on canvas
     *
     * @return value of y
     */
    @Override
    public double getYCoordinate()
    {
        return line.getY();
    }

    /**
     * Retrieve selected thickness for the shape
     *
     * @return thickness level 1-10
     */
    @Override
    public double getThickness()
    {
        return line.getThickness();
    }

    /**
     * Retrieve selected color for the shape
     *
     * @return value of color
     */
    @Override
    public Color getColor()
    {
        return color;
    }

    /**
     * Retrieve selected shape color filling option
     *
     * @return true if filled, false otherwise
     */
    @Override
    public boolean getFilled()
    {
        System.out.println("Line does not have fill option");
        return false;
    }

    /**
     * Draw shape on canvas with GraphicsContext
     *
     * @param graphics to draw on canvas
     */
    @Override
    public void drawShape(GraphicsContext graphics)
    {
        graphics.setStroke(color);
        graphics.setLineWidth(line.getThickness());
        graphics.strokeLine(line.getX(), line.getY(), line.getX2(), line.getY2());
    }
}
