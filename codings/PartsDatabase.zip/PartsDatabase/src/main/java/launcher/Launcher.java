package launcher;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class Launcher
{
    private static FileWriter modelWriter;
    private static FileWriter viewWriter;

    public static void main(String[] args)
    {

        exportParts();
    }

    public static void exportParts()
    {
        String model_destination = "files/model.txt";
        String view_destination = "files/view.txt";

        String[] asian = {
            "Asian Indian", "Cambodian", "Chinese", "Filipino", "Hmong", "Indonesian", "Japanese", "Korean",
            "Laotian", "Malaysian", "Pakistani", "Singaporean", "Taiwanese", "Thai", "Vietnamese", "Other Asian"
        };
        System.out.println(Arrays.toString(asian));

        // NOTE ************************************************
        // SAUK-SUIATTE needs to be sauk_suiatte in model's boolean code
        String[] americaIndian_alaskanNative = {
            "Alaska Native", "Chehalis", "Colville", "Cowlitz", "Hoh", "Hames", "Kalispei", "Lower Elwha", "Lummi",
            "Makah", "Muckleshoot", "Nisqually", "Nooksack", "Port Gamble Clallam", "Puyallup", "Quileute", "Quinault",
            "Samish", "Sauk-Suiattle", "Shoalwater", "Skokomish", "Snoqualmie", "Spokane", "Squaxin Island",
            "Stillaguamish", "Suquamish", "Swinomish", "Tulalip", "Upper Skagit", "Yakama", "Other Indian"
        };
        System.out.println(Arrays.toString(americaIndian_alaskanNative));

        String[] Hispanic_Latino = {
            "Cuban", "Dominican", "Spaniard", "Puerto Rican", "Mexican",
            "Central American", "South American", "Latin American", "Other Hispanic"
        };
        System.out.println(Arrays.toString(Hispanic_Latino));

        String[] Non_Hispanic = {
            "African", "African American", "Black", "Haitian", "Ethiopian",
            "White", "Caucasian", "European", "Russian", "Middle Eastern"
        };
        System.out.println(Arrays.toString(Non_Hispanic));

        String[] NativeHawaiian_OtherPacificIslander = {
            "Native Haiiwan", "Fijian", "Guamanian", "Chamorro", "Marianna Islander",
            "Melanesian", "Samoan", "Tongan", "Other Pacific Islander"
        };
        System.out.println(Arrays.toString(NativeHawaiian_OtherPacificIslander));


        try
        {
            modelWriter = new FileWriter(model_destination);
            viewWriter = new FileWriter(view_destination);


        // ASIAN
            modelWriter.append("//ASIAN -------------------------------------------------------------");
            ArrayList<String> asianMethods = writeToModelFile(asian);
            System.out.println(asianMethods);
            writeCardToViewFile("Asian","asian", "asian", asianMethods);

        // AMERICAN INDIAN & ALASKAN NATIVE
            modelWriter.append("//AMERICAN INDIAN & ALASKAN NATIVE -------------------------------------------------------------");
            ArrayList<String> americanIndian = writeToModelFile(americaIndian_alaskanNative);
            writeCardToViewFile("American Indian & Alaskan Native", "indian", "american-indian", americanIndian);

        // HISPANIC / LATINO
            modelWriter.append("//HISPANIC / LATINO -------------------------------------------------------------");
            ArrayList<String> hispanic = writeToModelFile(Hispanic_Latino);
            writeCardToViewFile("Hispanic/Latino", "hispanic", "hispanic-latino", hispanic);
        // NON HISPANIC
            modelWriter.append("//NON HISPANIC -------------------------------------------------------------");
            ArrayList<String> nonhispanic = writeToModelFile(Non_Hispanic);
            writeCardToViewFile("Non Hispanic", "nonhispanic", "non-hispanic", nonhispanic);

        // NATIVE HAWAIIAN / OTHER PACIFIC ISLANDER
            modelWriter.append("//NATIVE HAWAIIAN / OTHER PACIFIC ISLANDER ------------------------------------------------");
            ArrayList<String> hawaiian = writeToModelFile(NativeHawaiian_OtherPacificIslander);
            writeCardToViewFile("Native Hawaiian/Other Pacific Islander", "islander", "hawaiian-islander", hawaiian);

            modelWriter.close();
            viewWriter.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    private static ArrayList<String> writeToModelFile(String[] contents) throws IOException
    {
        ArrayList<String> methods = new ArrayList<String>();

        System.out.println("test 1");
        modelWriter.append("\n");
        for (int i = 0; i < contents.length; i++)
        {
           modelWriter.append("[DisplayName(\"" + contents[i] + "\")]");
           modelWriter.append("\n");

           String currentMethod = "is" + contents[i].replaceAll("\\s", "");
           modelWriter.append("public bool " + currentMethod + " { get; set; }");
           methods.add(currentMethod);

           modelWriter.append("\n");
        }
        modelWriter.append("\n");
        modelWriter.append("\n");

        return methods;
    }

    private static void writeCardToViewFile(String displayText, String headingID, String bodyID, ArrayList<String> contents) throws IOException
    {
        System.out.println("test 2");

        viewWriter.append("<!-- " + displayText.toUpperCase() + " CARD START -->");
        viewWriter.append("\n");

    // CARD DIV
        viewWriter.append("<div class=\"card\">");
        viewWriter.append("\n");

    // CARD TITLE
        viewWriter.append("\t<div class=\"card-header\" role=\"tab\" id=\"" + headingID + "-heading\">");
        viewWriter.append("\n");

            viewWriter.append("\t\t<h5 class=\"mb-0\">");
            viewWriter.append("\n");
                viewWriter.append("\t\t\t<a href=\"#" + bodyID + "\"" + " data-toggle=\"collapse\" data-parent=\"#accordion\" " +
                        "aria-expanded=\"true\">");
                    viewWriter.append("\n");
                    viewWriter.append("\t\t\t\t" + displayText);
                    viewWriter.append("\n");
                viewWriter.append("\t\t\t</a>");
            viewWriter.append("\n");
            viewWriter.append("\t\t</h5>");

        viewWriter.append("\n");
        viewWriter.append("\t</div>");
    // CARD TITLE CLOSES


    // CARD BODY
        viewWriter.append("\t<div id=\"" + bodyID + "\" class=\"collapse\" role=\"tabpanel\" aria-labelledby=\"" +
                headingID + "-heading\">");
        viewWriter.append("\n");

            viewWriter.append("\t\t<div class=\"card-block\">");
            viewWriter.append("\n");
                viewWriter.append("\t\t\t<div class=\"form-row\">");
                viewWriter.append("\n");

                viewWriter.append("\t\t\t\t<ul>");
                viewWriter.append("\n");

                    // LOOP THROUGH CONTENTS AND ASSIGN METHODS
                    for (int i = 0; i < contents.size(); i++)
                    {
                        viewWriter.append("\t\t\t\t\t<li>");
                        viewWriter.append("\n");
                        viewWriter.append("\t\t\t\t\t\t@Html.CheckBoxFor(model => model.ConsideredRaceAndEthnicity." + contents.get(i) + ", new { htmlAttributes = new { @class = \"form-control race-checkbox\" } })");
                        viewWriter.append("\n");
                        viewWriter.append("\t\t\t\t\t\t@Html.LabelFor(model => model.ConsideredRaceAndEthnicity." + contents.get(i) + ", htmlAttributes: new { @class = \"control-label\" })");
                        viewWriter.append("\n");
                        viewWriter.append("\t\t\t\t\t</li>");
                        viewWriter.append("\n");
                    }

                viewWriter.append("\t\t\t\t</ul>");

                viewWriter.append("\n");
                viewWriter.append("\t\t\t</div>");
            viewWriter.append("\n");
            viewWriter.append("\t\t</div>");

        viewWriter.append("\n");
        viewWriter.append("\t</div>");
    // CARD BODY CLOSES


    // CARD DIV CLOSES
        viewWriter.append("\n");
        viewWriter.append("</div>");
        viewWriter.append("\n");
        viewWriter.append("<!-- " + displayText.toUpperCase() + " CARD END -->");
        viewWriter.append("\n");

    }


}