package adapters;

import drawing.IShape;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import shapes.Star;

public class StarAdapter implements IShape
{
    private Star star;
    private boolean isFilled;
    private Color color;

    /**
     * Constructor for the adapter
     *
     * @param star - selected star by the user
     * @param isFilled - fill color option
     */
    public StarAdapter(Star star, boolean isFilled)
    {
        this.star = star;
        this.isFilled = isFilled;
        this.color = star.getColor();
    }

    /**
     * Setting the thickness of shape's stroke
     *
     * @param value - 1-10 of thickness level
     * @return Shape with selected stroke thickness
     */
    @Override
    public IShape setThickness(double value)
    {
        star.setThickness(value);
        return this;
    }

    /**
     * Setting the color of shape
     *
     * @param value - selected color
     * @return Shape with selected color value
     */
    @Override
    public IShape setColor(Color value)
    {
        color = value;
        return this;
    }

    /**
     * Toggle filling shape with color
     *
     * @param value - selected fill option
     * @return Shape with selected fill option
     */
    @Override
    public IShape setFilled(boolean value)
    {
        isFilled = value;
        return this;
    }

    /**
     * Retrieve selected x coordinate to draw on canvas
     *
     * @return value of x
     */
    @Override
    public double getXCoordinate()
    {
        return star.getX();
    }

    /**
     * Retrieve selected y coordinate to draw on canvas
     *
     * @return value of y
     */
    @Override
    public double getYCoordinate()
    {
        return star.getY();
    }

    /**
     * Retrieve selected thickness for the shape
     *
     * @return thickness level 1-10
     */
    @Override
    public double getThickness()
    {
        return star.getThickness();
    }

    /**
     * Retrieve selected color for the shape
     *
     * @return value of color
     */
    @Override
    public Color getColor()
    {
        return color;
    }

    /**
     * Retrieve selected shape color filling option
     *
     * @return true if filled, false otherwise
     */
    @Override
    public boolean getFilled()
    {
        return isFilled;
    }

    /**
     * Draw shape on canvas with GraphicsContext
     *
     * @param graphics to draw on canvas
     */
    @Override
    public void drawShape(GraphicsContext graphics)
    {
        graphics.setStroke(color);
        graphics.setLineWidth(star.getThickness());

        if (isFilled)
        {
            graphics.setFill(color);
            graphics.fillPolygon(star.getXPoints(), star.getyPoints(), star.getXPoints().length);
        } else
        {
            graphics.strokePolygon(star.getXPoints(), star.getyPoints(), star.getXPoints().length);
        }
    }
}
