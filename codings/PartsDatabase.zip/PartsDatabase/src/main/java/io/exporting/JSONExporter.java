package io.exporting;

/**
 * @author: Duck Nguyen
 * @date:   03/03/2018
 *
 * JSONEXporter exports car parts from model to parts.json
 */

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import io.IExporter;
import model.CarPart;
import model.PartsModel;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;

public class JSONExporter implements IExporter
{
    private String destination = "files/parts.json";
    private Collection<CarPart> partsToWrite;
    private Gson writer;

    /**
     * Exports all CarPart objects in the application to a text file
     *
     * @param data - model data to write to file in JSON format
     */
    @Override
    public void exportParts(PartsModel data)
    {
        try (FileWriter destinationFile = new FileWriter(destination))
        {
            writer = new GsonBuilder().setPrettyPrinting().create();
            writer.toJson(data.getParts(), destinationFile);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}