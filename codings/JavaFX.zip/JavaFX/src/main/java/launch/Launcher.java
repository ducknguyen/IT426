package launch;

/**
 * Launcher lauches the calculator application
 *
 * @author  Duck Nguyen
 * @version 1.0
 * @since   2018-01-20
 */
import calculator.Calculator;
import calculator_controller.CalculatorController;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import ui.CalculatorUI;

public class Launcher extends Application
{

    /**
     * Main entry point for Calculator Application
     *
     * @param primaryStage - the primary stage for the calculator application
     */
    @Override
    public void start(Stage primaryStage) throws Exception
    {
        Calculator model = new Calculator();
        CalculatorController controller = new CalculatorController(model);
        CalculatorUI view = new CalculatorUI(controller);

        Scene scene = new Scene(view.asParent(),500,520);

        primaryStage.setTitle("Calculator");
        primaryStage.setScene(view.setStylePrimaryLayout(scene));
        primaryStage.show();
    }

    public static void main(String[] args)
    {
        Application.launch(args);
    }
}