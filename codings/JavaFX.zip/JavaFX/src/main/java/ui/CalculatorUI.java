package ui;

/**
 * CalculatorUI builds and displays the user interface for a simple calculator
 * CalculatorUI.class acts as the View
 *
 * @author  Duck Nguyen
 * @version 1.0
 * @since   2018-01-20
 */
import calculator_controller.CalculatorController;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;


public class CalculatorUI
{
    private GridPane calculatorUI;
    private HBox calculatorOuputBox;
    private Label calculatorOutputText;

    private static final String[] CALCULATOR_KEYS = {
            "%", "\u221A","x\u00B2","CE",
            "7", "8", "9", "+",
            "4", "5", "6", "-",
            "1", "2", "3", "*",
            "0", "Enter", "/"
    };
    private static final int TOTAL_KEYS = CALCULATOR_KEYS.length;

    private CalculatorController controller;

    /**
     * Construtor for CalculatorUI
     *
     * @param controller instance of Controller to communicate with View
     */
    public CalculatorUI(CalculatorController controller)
    {
        this.controller = controller;

        calculatorUI = new GridPane();
        styleCalculatorUI();

        calculatorOuputBox = new HBox();
        styleCalculatorOutputBox();

        calculatorOutputText = new Label("");
        styleCalculatorOutputText();

        calculatorOuputBox.getChildren().add(calculatorOutputText);
        calculatorUI.add(calculatorOuputBox,0,0,4,1);

        buildCalculatorUI();
    }

    /**
     * Retrieve CalculatorUI view
     *
     * @return CaluclatorUI
     */
    public Parent asParent()
    {
        return calculatorUI;
    }

    /**
     * Assign styling for PrimaryLayout
     *
     * @param primaryLayout PrimaryLayout for the Calculator
     */
    public Scene setStylePrimaryLayout(Scene primaryLayout)
    {
        primaryLayout.getStylesheets().add(this.getClass().getClassLoader().getResource("css/calculator.css").toExternalForm());

        // font style from GoogleFonts
        primaryLayout.getStylesheets().add("https://fonts.googleapis.com/css?family=Anton");

        return primaryLayout;
    }

    private void styleCalculatorUI()
    {
        calculatorUI.getStyleClass().add("calculatorUI");
    }

    private void styleCalculatorOutputBox()
    {
        calculatorOuputBox.getStyleClass().add("calculatorOutputBox");
        calculatorOuputBox.setPrefHeight(58);
        calculatorOuputBox.setAlignment(Pos.BOTTOM_RIGHT);
    }

    private void styleCalculatorOutputText()
    {
        calculatorOuputBox.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID,
                CornerRadii.EMPTY, BorderWidths.DEFAULT)));
    }

    private void buildCalculatorUI()
    {
        for(int colNum = 0; colNum < TOTAL_KEYS; colNum++)
        {
            Button currentButton = new Button(CALCULATOR_KEYS[colNum]);
            currentButton.setPrefWidth(55);
            currentButton.setPrefHeight(55);

            if (CALCULATOR_KEYS[colNum] == "Enter")
            {
                calculatorUI.add(currentButton, colNum % 4, colNum / 4 + 1,2,1);
                currentButton.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
            }
            else if (CALCULATOR_KEYS[colNum] == "/")
            {
                calculatorUI.add(currentButton, colNum % 4 + 1, colNum / 4 + 1);
            }
            else
            {
                calculatorUI.add(currentButton, colNum % 4, colNum / 4 + 1);
            }
            currentButton.setOnAction(e -> processButtonData(e));
        }
    }

    private void processButtonData(ActionEvent e)
    {
        String buttonData = ((Button) e.getSource()).getText();
        String textToDisplay = this.controller.processButtonData(buttonData);

        calculatorOutputText.setText(textToDisplay);
    }
}