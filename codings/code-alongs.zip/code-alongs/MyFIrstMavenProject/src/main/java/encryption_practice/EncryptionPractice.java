package encryption_practice;

import org.jasypt.util.password.BasicPasswordEncryptor;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class EncryptionPractice
{
    public static void main(String[] args)
    {
        Scanner console = new Scanner(System.in);

        //promt for username/password
        System.out.println("Username:");
        String username = console.nextLine();

        System.out.println("Password:");
        String password = console.nextLine();

        //class from jasypt to encrypt password
        BasicPasswordEncryptor encryptor = new BasicPasswordEncryptor();
        password = encryptor.encryptPassword(password);

        //show the user
        System.out.println("Encrypted password: " + password);

        System.out.println("Confirm password:");
        String confirm = console.nextLine();

        //check if password matches
        if(encryptor.checkPassword(confirm, password))
        {
            System.out.println("Password recognized!");
        }
        else
        {
            System.out.println("Password not recognized!");
        }


        // this switch statement does not work unless using most recent version of java
        String message = "Hello WOrld!";
        switch (message)
        {
            case "Hello":
                break;
            case "Hello world":
                break;
            case "Hello world!":
                break;
        }

        try (Scanner fileReader = new Scanner(new FileInputStream("input.txt")))
        {
            //do something
        }
        catch (FileNotFoundException e)
        {
            //do something else
        }
    }
}
