package io.exporting;

import io.IExporter;
import model.CarPart;
import model.PartsModel;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;


public class CSVExporter implements IExporter
{
    private String destination = "files/parts.csv";
    private Collection<CarPart> parts;

    private FileWriter writer;
    private static final String HEADER_LINE = "PartID, Manufacturer, ListPrice";
    private static final String LINE_BREAK = "\n";

    /**
     * Exports all CarPart objects in the application to a text file
     *
     * @param data - model data to write to file
     */
    @Override
    public void exportParts(PartsModel data)
    {
        try
        {
            writer = new FileWriter(destination);
            parts = data.getParts();

            // header of csv file
            writer.append(HEADER_LINE);
            writer.append(LINE_BREAK);

            // write the file's body content
            convertToCSVFormat();

            writer.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }


// HELPER METHODS

    private void convertToCSVFormat() throws IOException
    {

        for (CarPart part : parts)
        {
            writer.append(part.getId() + ", ");
            writer.append(part.getManufacturer() + ", ");
            writer.append(Double.toString(part.getListPrice()));
            writer.append(LINE_BREAK);
        }
    }
}