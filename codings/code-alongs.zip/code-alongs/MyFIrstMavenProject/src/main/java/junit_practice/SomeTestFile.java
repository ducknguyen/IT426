package junit_practice;

import org.junit.Assert;
import org.junit.Test;

public class SomeTestFile
{
    @Test
    public void testSomeMethod()
    {
        //do something
    }

}
