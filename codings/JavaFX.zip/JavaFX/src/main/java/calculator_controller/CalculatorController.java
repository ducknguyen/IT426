package calculator_controller;

import calculator.Calculator;

/**
 * Calculator contains all state information and event handlers for intecting with the calculator
 * CalculatorController.class acts as the Controller
 *
 * @author  Duck Nguyen
 * @version 1.0
 * @since   2018-01-28
 */
public class CalculatorController
{
    private Calculator model;
    private String mathProblem = "";
    private String calculationResult = "";

    /**
     * CalculatorController constructors
     *
     * @param model - Model that holds data and perform calculation
     */
    public CalculatorController(Calculator model)
    {
        this.model = model;
    }

    /**
     * CalculatorController constructors
     *
     * @param buttonData - Text data from clicked button to be processed by Controller
     * @return result of calculation as text
     */
    public String processButtonData(String buttonData)
    {
        if  (buttonData.equals("CE"))   calculationResult = "";
        else                            calculationResult = buildMathProblem(buttonData);

        return calculationResult;
    }

    private String buildMathProblem(String buttonData)
    {
        if      (this.model.isOperand(buttonData))          processOperands(buttonData);
        else if (this.model.isOperator(buttonData))         processOperators(buttonData);
        else if (this.model.isSpecialOperator(buttonData))  processSpecialOperator(buttonData);
        else                                                processEnterButton(buttonData);

        return calculationResult;
    }

    private void processOperands(String buttonData)
    {
        mathProblem += buttonData;
        calculationResult += buttonData;
    }

    private void processOperators(String buttonData)
    {
        mathProblem += " " + buttonData + " ";
        calculationResult = "";
    }

    private void processSpecialOperator(String buttonData)
    {
        mathProblem += buttonData + " ";
        calculationResult = buttonData;
    }

    private void processEnterButton(String buttonData)
    {
        mathProblem += " " + buttonData;
        this.model.calculateMathProblem(mathProblem);
        calculationResult = Double.toString(this.model.getCalculationResult());
    }
}