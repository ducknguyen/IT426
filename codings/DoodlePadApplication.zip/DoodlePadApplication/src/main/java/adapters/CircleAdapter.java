package adapters;

/**
 * @author: Duck Nguyen
 * @date: 03/21/2018
 *
 * Circle adapter is the adapter needed for Circle to be compatible with SavedShapes
 */

import drawing.IShape;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import shapes.Circle;

public class CircleAdapter implements IShape
{
    private Circle circle;
    private boolean isFilled;
    private Color color;

    /**
     * Constructor for the adapter
     * @param selectedCircle - cirlce object as selected by user
     * @param isFilled - color fill option
     */
    public CircleAdapter(Circle selectedCircle, boolean isFilled)
    {
        this.circle = selectedCircle;
        this.isFilled = isFilled;
        this.color = selectedCircle.getColor();
    }

    /**
     * Setting the thickness of shape's stroke
     *
     * @param value - 1-10 of thickness level
     * @return Shape with selected stroke thickness
     */
    @Override
    public IShape setThickness(double value)
    {
        circle.setThickness(value);
        return this;
    }

    /**
     * Setting the color of shape
     *
     * @param value - selected color
     * @return Shape with selected color value
     */
    @Override
    public IShape setColor(Color value)
    {
        color = value;
        return this;
    }

    /**
     * Toggle filling shape with color
     *
     * @param value - selected fill option
     * @return Shape with selected fill option
     */
    @Override
    public IShape setFilled(boolean value)
    {
        isFilled = value;
        return this;
    }

    /**
     * Retrieve selected x coordinate to draw on canvas
     *
     * @return value of x
     */
    @Override
    public double getXCoordinate()
    {
        return circle.getX();
    }

    /**
     * Retrieve selected y coordinate to draw on canvas
     *
     * @return value of y
     */
    @Override
    public double getYCoordinate()
    {
        return circle.getY();
    }

    /**
     * Retrieve selected thickness for the shape
     *
     * @return thickness level 1-10
     */
    @Override
    public double getThickness()
    {
        return circle.getThickness();
    }

    /**
     * Retrieve selected color for the shape
     *
     * @return value of color
     */
    @Override
    public Color getColor()
    {
        return color;
    }

    /**
     * Retrieve selected shape color filling option
     *
     * @return true if filled, false otherwise
     */
    @Override
    public boolean getFilled()
    {
        return isFilled;
    }

    /**
     * Draw shape on canvas with GraphicsContext
     *
     * @param graphics to draw on canvas
     */
    @Override
    public void drawShape(GraphicsContext graphics)
    {
        graphics.setStroke(color);
        graphics.setLineWidth(circle.getThickness());

        if (isFilled)
        {
            graphics.setFill(color);
            graphics.fillOval(circle.getX(), circle.getY(), circle.getRadius(), circle.getRadius());
        } else
        {
            graphics.strokeOval(circle.getX(), circle.getY(), circle.getRadius(), circle.getRadius());
        }
    }
}
