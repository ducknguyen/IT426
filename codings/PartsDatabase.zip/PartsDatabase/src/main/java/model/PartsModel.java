package model;

import io.IExporter;
import io.IImporter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

/**
 * @author: Duck Nguyen
 * @date:   03/03/2018
 *
 * PartsModel contains a collection of CarPart objects that are created by the user.
 */

public class PartsModel
{
    private Collection<CarPart> parts;

    /**
     * Constructor for PartsModel
     */
    public PartsModel()
    {
        parts = new ArrayList<CarPart>();
    }

    /**
     * Add a CarPart object to model
     * @param part - part to be added
     */
    public void addPart(CarPart part)
    {
        parts.add(part);
    }

    /**
     * Retrieve all current CarPart stored in model
     *
     * @return collection of CarPart
     */
    public Collection<CarPart> getParts()
    {
        return Collections.unmodifiableCollection(parts);
    }

    /**
     * Save parts to file
     * @param exporter - Exporter strategy to use
     */
    public void saveParts(IExporter exporter)
    {
        exporter.exportParts(this);
    }

    /**
     * Retrieve parts from file
     * @param importer - Importer strategy to use
     */
    public void loadParts(IImporter importer)
    {
        importer.importParts(this);
    }

    /**
     * Remove all CarPart currently stored in model
     */
    public void clear()
    {
        parts.clear();
    }
}
