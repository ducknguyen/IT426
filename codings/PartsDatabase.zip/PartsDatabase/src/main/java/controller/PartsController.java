package controller;

/**
 * @author: Duck Nguyen
 * @date:   03/03/2018
 *
 * Controller class takes requests from the user and funnels them to our PartsModel class.
 */

import io.exporting.CSVExporter;
import io.exporting.JSONExporter;
import io.exporting.JavaExporter;
import io.exporting.XMLExporter;
import io.importing.CSVImporter;
import io.importing.JSONImporter;
import io.importing.JavaImporter;
import io.importing.XMLImporter;
import model.CarPart;
import model.PartsModel;

import java.util.Collection;

public class PartsController
{
    private PartsModel model;

    /**
     * Constructor for controller
     */
    public PartsController()
    {
        model = new PartsModel();
    }

    /**
     * Add a part to our model
     *
     * @param id           - id of the part to be added
     * @param manufacturer - manufacturer of the part to be added
     * @param listPrice    - price of the part to be added
     */
    public void addPart(String id, String manufacturer, double listPrice)
    {
        model.addPart(new CarPart(id, manufacturer, listPrice));
    }

    /**
     * Retrieve all parts stored inside our model
     *
     * @return a collection of CarPart
     */
    public Collection<CarPart> getParts()
    {
        Collection<CarPart> allParts = model.getParts();
        return allParts;
    }

    /**
     * Import to file based on the strategy selected by user
     *
     * @param strategy -  user choice of import strategy
     */
    public void importParts(String strategy)
    {
        // clear current data before import
        model.clear();

        if      (strategy == "Java")    model.loadParts(new JavaImporter());
        else if (strategy == "JSON")    model.loadParts(new JSONImporter());
        else if (strategy == "XML")     model.loadParts(new XMLImporter());
        else                            model.loadParts(new CSVImporter());
    }

    /**
     * Export to file based on the strategy selected by user
     *
     * @param strategy -  user choice of export strategy
     */
    public void exportParts(String strategy)
    {
        if      (strategy == "Java")    model.saveParts(new JavaExporter());
        else if (strategy == "JSON")    model.saveParts(new JSONExporter());
        else if (strategy == "XML")     model.saveParts(new XMLExporter());
        else                            model.saveParts(new CSVExporter());
    }
}