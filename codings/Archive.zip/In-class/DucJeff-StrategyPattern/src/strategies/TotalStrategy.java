package strategies;

import rankings.Review;

import java.util.List;

public class TotalStrategy implements IStrategy {
    @Override
    public int getScore(int year, List<Review> reviews) {

        int total = 0;
        for (Review review : reviews) {
            if(review.getYear() == year) {
                for (int i = 0; i < review.getKpis().length; i++) {
                    total += review.getKpis()[i];
                }
            }
        }
        return total;
    }

}
