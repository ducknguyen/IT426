package ui;

/**
 * @author: Duck Nguyen
 * @date: 03/21/2018
 *
 * DoodlePadGUI acts as the user interface for our doodle pad application
 */

import adapters.*;
import drawing.IShape;
import drawing.SavedShapes;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import shapes.*;

import java.io.File;
import java.util.Random;


public class DoodlePadGUI extends Application
{
// CONSTANTS
    private final int GUI_WIDTH = 1000;
    private final int GUI_HEIGHT = 1200;
    private final int CANVAS_CONTROLS_HEIGHT = 200;
    private final int CANVAS_WIDTH = 1000;
    private final int CANVAS_HEIGHT = 1000;

// GUI COMPONENTS
    private VBox doodleCanvasGUI;

    private HBox canvasControls;
    private ToggleGroup options;
    private ColorPicker colorPicker;
    private CheckBox fillOption;
    private TextField displayThickness;
    private Slider thicknessSlider;

    private String selectedShape;
    private Color selectedColor;
    private boolean selectedFillOption;
    private double selectedThickness;

    private Canvas canvas;
    private GraphicsContext graphics;

// SHAPES
    private IShape shapeToDraw;
    private SavedShapes savedShapes;


    @Override
    public void start(Stage primaryStage)
    {
        primaryStage.setScene(buildGUI());
        primaryStage.setTitle("Doodle Pad");
        primaryStage.show();
    }


// BUILD AND STYLE GUI

    public Scene buildGUI()
    {
        savedShapes = new SavedShapes();

        doodleCanvasGUI = new VBox(10);
        styleGUI();

        canvasControls  = new HBox(10);
        buildCanvasControls();
        styleControls();

        canvas = new Canvas(CANVAS_WIDTH, CANVAS_HEIGHT);
        graphics = canvas.getGraphicsContext2D();
        handleCanvas();

        doodleCanvasGUI.getChildren().addAll(canvasControls, canvas);

        return new Scene(doodleCanvasGUI, GUI_WIDTH,GUI_HEIGHT);
    }

    private void styleGUI()
    {
        doodleCanvasGUI.setPrefWidth(GUI_WIDTH);
        doodleCanvasGUI.setPrefHeight(GUI_HEIGHT);
        doodleCanvasGUI.getStylesheets().add(this.getClass().getClassLoader().getResource("css/gui-styles.css").toExternalForm());
    }



// CANVAS CONTROLS

    private void buildCanvasControls()
    {
        options = buildControlOptions();
        handleToggleGroup();

        colorPicker = new ColorPicker();
        colorPicker.setStyle("-fx-color-label-visible: false ;");

        fillOption = new CheckBox();
        Label fillLabel = new Label("Fill");
        handleFillOption();

        Label thicknessLabel = new Label("Thickness");
        displayThickness = new TextField();

        thicknessSlider = buildThicknessSlider();
        handleThicknessSlider();

        canvasControls.getChildren().addAll(fillOption, fillLabel, colorPicker, thicknessLabel, displayThickness, thicknessSlider);
    }

    private void styleControls()
    {
        canvasControls.setPrefWidth(GUI_WIDTH);
        canvasControls.setPrefHeight(CANVAS_CONTROLS_HEIGHT);
        canvasControls.setPadding(new Insets(20));
        canvasControls.setAlignment(Pos.CENTER_LEFT);
    }


// CONTROLS BUILDS

    private ToggleGroup buildControlOptions()
    {
        File imagesDirectory = new File("images");
        File[] images = imagesDirectory.listFiles();

        ToggleGroup shapeOptions = new ToggleGroup();
        Image currentImage;
        ToggleButton currentOption;

        for (File image : images)
        {
            String imageName = image.getName();
            currentImage = new Image(getClass().getClassLoader().getResourceAsStream("images/"+imageName),
                    30,30,false,false);

            // create option button and assign id for look up
            currentOption = new ToggleButton("", new ImageView(currentImage));
            currentOption.setToggleGroup(shapeOptions);
            currentOption.setId(imageName.substring(0, imageName.lastIndexOf(".")));

            canvasControls.getChildren().add(currentOption);
        }

        return shapeOptions;
    }

    private Slider buildThicknessSlider()
    {
        Slider slider = new Slider();
        slider.setMin(1);
        slider.setMax(10);
        slider.setShowTickLabels(true);

        return slider;
    }


// CONTROLS HANDLES

    private void handleToggleGroup()
    {
        options.selectedToggleProperty().addListener(new ChangeListener<Toggle>()
        {
            @Override
            public void changed(ObservableValue<? extends Toggle> observable, Toggle oldValue, Toggle newValue)
            {
                ToggleButton test = (ToggleButton)newValue.getToggleGroup().getSelectedToggle();
                selectedShape = test.getId();
            }
        });
    }

    private void handleFillOption()
    {
        fillOption.selectedProperty().addListener(new ChangeListener<Boolean>()
        {
            @Override
            public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue)
            {
                selectedFillOption = newValue;
            }
        });
    }

    private void handleThicknessSlider()
    {
        thicknessSlider.valueProperty().addListener(new ChangeListener<Number>()
        {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue)
            {
                double retrievedValue = Math.round(newValue.doubleValue()) * 1.0;
                displayThickness.setText(Double.toString(retrievedValue));
                selectedThickness = retrievedValue;
            }
        });
    }


// HANDLE CANVAS

    private void handleCanvas()
    {
        canvas.addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>()
        {
            @Override
            public void handle(MouseEvent e)
            {
                shapeToDraw = processShapeToDraw(e.getX(), e.getY());

                if (savedShapes.add(shapeToDraw))
                {
                    savedShapes.drawShapes(graphics);
                }
                else
                {
                    savedShapes.update(shapeToDraw, selectedThickness, selectedColor, selectedFillOption);
                    savedShapes.drawShapes(graphics);
                }

            }
        });
    }

    private IShape processShapeToDraw(double x, double y)
    {
        IShape shapeToDraw = null;
        selectedColor = colorPicker.getValue();

        if (selectedShape.equals("line"))
        {
            Random rand = new Random(50);
            shapeToDraw = new LineAdapter(new Line(x, y, x + 30, y*rand.nextDouble(), selectedThickness, selectedColor));
        }
        else if (selectedShape.equals("oval"))
        {
            shapeToDraw = new CircleAdapter(new Circle(50.0, x, y, selectedThickness, selectedColor),selectedFillOption);
        }
        else if (selectedShape.equals("polygon"))
        {
            double xPoints[]   = {x, x+75, x+100, x+125, x+200, x+150, x+160, x+100, x+40, x+50};
            double yPoints[]   = {y, y-10, y-75, y-10, y, y+40, y+105, y+65, y+105, y+40};
            shapeToDraw = new StarAdapter(new Star(x, y, xPoints, yPoints, selectedThickness, selectedColor),selectedFillOption);
        }
        else if (selectedShape.equals("triangle"))
        {
            shapeToDraw = new TriangleAdapter(new Triangle(x, y, 30.0, 30.0, selectedThickness, selectedColor), selectedFillOption);
        }
        else
        {
            shapeToDraw = new RectangleAdapter(new Rectangle(x, y, 90.0, 50.0, selectedThickness, selectedColor), selectedFillOption);
        }
        return shapeToDraw;
    }
}
