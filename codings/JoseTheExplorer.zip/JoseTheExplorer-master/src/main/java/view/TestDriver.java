/* File Name: TestDriver.java
 * Author: Tim Roush
 * Date: 02/10/18
 * Description: Throwaway test driver for model activity
 */

// TODO - DELETE THIS FILE BEFORE PUBLISHING

package view;

import controller.Controller;
import model.Adventure;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class TestDriver {

    private static Scanner kb = new Scanner(System.in);
    private static Controller c = new Controller();
    //private static DBOperator db = new DBOperator();

    public static void main(String[] args) {

        while(true) {
            System.out.println("**** JOSE THE EXPLORER ****");
            System.out.println("Total Steps: " + c.getStepsForAllHikes());
            System.out.println("Total BPM: " + c.getBPMForAllHikes());
            System.out.println("1. Add a new hike");
            System.out.println("2. View all hikes");
            System.out.println("3. Add vitals to a hike");
            System.out.println("4. View Hike Details");
            System.out.println("5. Update a hikes backpack");
            System.out.println("6. See previous locations");
            System.out.println("7. Add reminder to a hike");
            System.out.print("Your Choice: ");
            int choice = kb.nextInt();
            kb.nextLine();

            if (choice == 1) {
                System.out.print("Location: ");
                String location = kb.nextLine();
                System.out.print("When: ");
                String when = kb.nextLine();

                c.createNewHike(location, when);
            } else if (choice == 2) {
                ArrayList<Adventure> hikes = c.getAllHikes();
                for (Adventure hike : hikes) {
                    System.out.println(hike.getID() + ": " + hike.getLocation() + " - " + hike.getWhen());
                }
            } else if (choice == 3) {
                System.out.print("Hike #: ");
                int hikeID = kb.nextInt();
                kb.nextLine();
                System.out.print("Steps: ");
                int steps = kb.nextInt();
                kb.nextLine();
                c.setHikeSteps(hikeID, steps);
                System.out.print("BPM #: ");
                int bpm = kb.nextInt();
                kb.nextLine();
                c.setHikeBPM(hikeID, bpm);
            } else if (choice == 4) {
                System.out.print("Hike #: ");
                int hikeID = kb.nextInt();
                kb.nextLine();
                Adventure hike = c.getSpecificHike(hikeID);
                ArrayList<String> reminders = c.getHikeReminders(hikeID);

                System.out.println("Location: " + hike.getLocation());
                System.out.println("Date: " + hike.getWhen());
                System.out.println("Steps: " + hike.getSteps());
                System.out.println("BPM: " + hike.getBPM());

                for (String reminder : reminders) {
                    System.out.println(reminder);
                }

                System.out.println("Backpack: ");
                HashMap<String, Boolean> backpack = c.getHikeBackpack(2);

                for (String item : backpack.keySet()) {
                    String check = " ";
                    if (backpack.get(item)) check = "X";
                    System.out.println(" [" + check + "] - " + item);
                }
            } else if (choice == 5){
                System.out.print("Hike #: ");
                int hikeID = kb.nextInt();
                kb.nextLine();
                System.out.print("Item: ");
                String item = kb.nextLine();
                System.out.print("Value: ");
                int checkValue = kb.nextInt();
                kb.nextLine();
                boolean checked = checkValue == 1 ? true : false;
                c.updateBackpackItem(hikeID, item, checked);
            } else if (choice == 6) {
                ArrayList<String> locations = c.getPreviousLocations();
                for (String location : locations) {
                    System.out.println(location);
                }
            } else if (choice == 7) {
                System.out.print("Hike #: ");
                int hikeID = kb.nextInt();
                kb.nextLine();
                System.out.print("Reminder text: ");
                String reminder = kb.nextLine();
                c.addReminderToHike(hikeID, reminder);
            } else {
                System.out.println("OOPS!");
            }
        }


    }
}
