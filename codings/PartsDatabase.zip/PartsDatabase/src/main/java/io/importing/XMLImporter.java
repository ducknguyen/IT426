package io.importing;

/**
 * @author: Duck Nguyen
 * @date:   03/03/2018
 *
 * XMLImporter imports car parts from parts.xml file to model
 */

import io.IImporter;
import model.CarPart;
import model.PartsModel;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;

public class XMLImporter implements IImporter
{
    private String destination = "files/parts.xml";

    private DocumentBuilderFactory docFactory;
    private DocumentBuilder docBuilder;
    private Document partsDocument;

    private NodeList partsFromFile;

    /**
     * Imports all CarPart elements from a XML file to the application
     *
     * @param data - model data to read from XML file
     */
    @Override
    public void importParts(PartsModel data)
    {
        try
        {
            File fileToRead = new File(destination);
            docFactory = DocumentBuilderFactory.newInstance();
            docBuilder = docFactory.newDocumentBuilder();

            partsDocument = docBuilder.parse(fileToRead);
            partsDocument.getDocumentElement().normalize();

            readAndConvert(data);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }


// HELPER METHODS

    private void readAndConvert(PartsModel data)
    {
        partsFromFile = partsDocument.getElementsByTagName("part");

        for (int i = 0; i < partsFromFile.getLength(); i++)
        {
            Node currentPart = partsFromFile.item(i);
            if(currentPart.getNodeType() == Node.ELEMENT_NODE)
            {
                Element current = (Element) currentPart;
                translateToCarPart(current, data);
            }
        }
    }

    private void translateToCarPart(Element current, PartsModel data)
    {
        String id = getElementContent(current, "id");
        String manufacturer = getElementContent(current, "manufacturer");
        String listPrice = getElementContent(current, "listprice");

        data.addPart(new CarPart(id, manufacturer, Double.parseDouble(listPrice)));
    }

    private String getElementContent(Element current, String tagName)
    {
        return current.getElementsByTagName(tagName).item(0).getTextContent();
    }
}