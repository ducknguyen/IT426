package calculator;

import java.util.Arrays;
import java.util.Stack;
import java.util.regex.Pattern;

/**
 * Calculator contains all state information and event handlers for intecting with the calculator
 * Calculator.class acts as the Model
 *
 * @author  Duck Nguyen
 * @version 1.0
 * @since   2018-01-28
 */
public class Calculator
{
    private String[] mathProblemBreakdown;
    private String mathProblem;
    private double calculationResult;

    private Stack<String> operators  = new Stack<String>();
    private Stack<Double> operands = new Stack<Double>();

    /**
     * Process entered math problem received from View
     * Dijkstra's two stack algorithm
     *
     * @param mathProblem full math problem as string to be processed
     */
    public void calculateMathProblem(String mathProblem)
    {
        mathProblemBreakdown = mathProblem.split(" ");

        for(int i = 0; i < mathProblemBreakdown.length; i++)
        {
            String currentText = mathProblemBreakdown[i];
            if(isOperator(currentText) || isSpecialOperator(currentText))
            {
                operators.push(currentText);
            }
            else if (currentText.equals("Enter"))
            {
                double operationResult = performMathOperation(operators, operands);
                operands.push(operationResult);
            }
            else
            {
                operands.push(Double.parseDouble(currentText));
            }
        }
        calculationResult = operands.pop();
    }

    private double performMathOperation(Stack<String> operators, Stack<Double> operands)
    {
        String currentOperator = operators.pop();
        double currentOperand = operands.pop();

        if      (currentOperator.equals("+"))           currentOperand = operands.pop() + currentOperand;
        else if (currentOperator.equals("-"))           currentOperand = operands.pop() - currentOperand;
        else if (currentOperator.equals("*"))           currentOperand = operands.pop() * currentOperand;
        else if (currentOperator.equals("/"))           currentOperand = operands.pop() / currentOperand;
        else if (currentOperator.equals("%"))           currentOperand = operands.pop() % currentOperand;
        else if (currentOperator.equals("\u221A"))      currentOperand = Math.sqrt(currentOperand);
        else if (currentOperator.equals("x\u00B2"))     currentOperand *= currentOperand;

        return currentOperand;
    }


    /**
     * Retrieve calculation result stored in Model
     *
     * @return result of calculation as double
     */
    public double getCalculationResult()
    {
        return calculationResult;
    }

    /**
     * Helper method to determine whether button data is an operand
     *
     * @return true if operand, false otherwise
     */
    public boolean isOperand(String buttonData)
    {
        return Pattern.matches("[0-9]",buttonData);
    }

    /**
     * Helper method to determine whether button data is an operator
     *
     * @return true if operator, false otherwise
     */
    public boolean isOperator(String buttonData)
    {
        return buttonData.equals("+") || buttonData.equals("-") || buttonData.equals("*") || buttonData.equals("/")
                || buttonData.equals("%");
    }

    /**
     * Helper method to determine whether button data is a special operator
     *
     * @return true if operand, false otherwise
     */
    public boolean isSpecialOperator(String buttonData)
    {
        return buttonData.equals("\u221A") || buttonData.equals("x\u00B2");
    }
}