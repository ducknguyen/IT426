package io.exporting;

/**
 * @author: Duck Nguyen
 * @date:   03/03/2018
 *
 * JavaExporter exports car parts from model to parts.dat
 */

import io.IExporter;
import model.PartsModel;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class JavaExporter implements IExporter
{
    private String destinationFile = "files/parts.dat";
    private ObjectOutputStream writer;

    /**
     * Exports all CarPart objects in the application to a text file
     *
     * @param data - model data to write to file as Java Object
     */
    @Override
    public void exportParts(PartsModel data)
    {
        try
        {
            writer = new ObjectOutputStream(new FileOutputStream(destinationFile));
            writer.writeObject(data.getParts());
            writer.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
