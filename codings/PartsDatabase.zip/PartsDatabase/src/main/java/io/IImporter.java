package io;


import model.PartsModel;

public interface IImporter
{
    /**
     * Imports all CarPart objects from a text file to the application
     *
     * @param data - model data to read from file
     */
    public void importParts(PartsModel data);
}
