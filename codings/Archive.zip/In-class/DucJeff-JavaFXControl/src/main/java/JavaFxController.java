import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.File;
import java.net.MalformedURLException;

public class JavaFxController extends Application {
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setScene(createImageViewer());
        primaryStage.setTitle("Select an image.");
        primaryStage.show();
    }

    public Scene createImageViewer() throws MalformedURLException {
        VBox parentBox = new VBox();

        parentBox.setAlignment(Pos.TOP_CENTER);
        parentBox.setPadding(new Insets(10));
        parentBox.setSpacing(5);

        HBox childBox = new HBox();
        parentBox.getChildren().add(childBox);

        childBox.setAlignment(Pos.TOP_CENTER);
        childBox.setPadding(new Insets(10));
        childBox.setSpacing(5);

        String[] choices = {"bear", "cat", "owl", "parrot"};
        RadioButton[] buttons = new RadioButton[choices.length];
        ToggleGroup group = new ToggleGroup();

        ImageView imageView = new ImageView();
        imageView.setFitHeight(400);
        imageView.setFitWidth(400);
        parentBox.getChildren().add(imageView);

        for (int i = 0; i < choices.length; i++) {
            RadioButton currentButton = new RadioButton(choices[i]);
            buttons[i] = currentButton;
            currentButton.setToggleGroup(group);

            currentButton.selectedProperty().addListener(new ChangeListener<Boolean>() {
                @Override
                public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
                    Image image = null;
                    try
                    {
                        image = new Image(new File("images/" + currentButton.getText() +".jpg").toURI().toURL().toString(), true);
                    } catch (MalformedURLException e)
                    {
                        e.printStackTrace();
                    }
                    imageView.setImage(image);
                }
            });
            childBox.getChildren().add(currentButton);
        }

        return new Scene(parentBox, 400, 500);
    }
}