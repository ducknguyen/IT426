package io.importing;

/**
 * @author: Duck Nguyen
 * @date:   03/03/2018
 *
 * JSONImporter imports car parts from parts.json to model
 */

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import io.IImporter;
import model.CarPart;
import model.PartsModel;

import java.io.FileReader;
import java.io.IOException;
import java.util.Collection;

public class JSONImporter implements IImporter
{
    private String destination = "files/parts.json";
    private Gson reader;
    /**
     * Imports all CarPart objects from a text file to the application
     *
     * @param data - model data to read from file
     */
    @Override
    public void importParts(PartsModel data)
    {
        try (FileReader destinationFile = new FileReader(destination)) {

            reader = new Gson();
            Collection<CarPart> parts = reader.fromJson(
                    destinationFile, new TypeToken<Collection<CarPart>>(){}.getType());

            for(CarPart part : parts)
            {
                data.addPart(part);
            }

            destinationFile.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
