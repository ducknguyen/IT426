/* File Name: Controller.java
 * Authors: Tim Roush
 * Date: 02/11/18
 * Description: "Jose The Explorer" MVC Component: Controller
 */
package controller;

import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import model.Adventure;
import model.DBOperator;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * A <code>Controller</code> object acts as a "middle man"
 * between the <code>Model</code> and <code>View</code>
 * components in MVC.
 *
 * <code>Controller</code> provides methods for a <code>View</code> component
 * to send output to the model while also receiving input back while still
 * providing a separation of concerns.  The <code>View</code> must store a
 * reference for all output fields within this object to allow for updating.
 */
public class Controller {


// FIELDS, OBJECTS, AND CONSTANTS


    private static DBOperator model;
    private static Stage stage;


// CONSTRUCTOR(S)


    /**
     * Creates a <code>Controller</code> object for the purpose of interacting
     * with an instance of a <code>DataModel</code> object.
     */
    public Controller() {
        //model = new DataModel();
        model = new DBOperator();
    }


// METHODS

    /**
     * Sets the stage to a new stage.
     * @param stage the stage to set the stage to.
     */
    public void setStage(Stage stage) {
        this.stage = stage;
    }

    /**
     * Changes the scene to a new scene.
     * @param newGrid The new scene to set to represented by a GridPane.
     */
    public void changeScene(GridPane newGrid) {
        stage.getScene().setRoot(newGrid);
    }

    /**
     * Gets the last inserted row.
     * @return an int represneting the last inserted row.
     */
    public int getLastInsertedRow() {
        return model.getLastInsertedRow();
    }

    /**
     * Creates a new hike by location and date.
     * @param location the location of the new hike.
     * @param date The date of the new hike.
     */
    public void createNewHike(String location, String date) {
        model.createNewHike(location, date);
    }

    /**
     * Sets the number of hike steps based on the hike id.
     * @param hikeID the id of the hike to set the steps of.
     * @param steps the number of steps to set to.
     */
    public void setHikeSteps(int hikeID, int steps) {
        model.setHikeSteps(hikeID, steps);
    }

    /**
     * Sets the number of bpm based on the hike id.
     * @param hikeID The hike id to set the number of bpm to.
     * @param bpm The bpm value to set to.
     */
    public void setHikeBPM(int hikeID, int bpm) {
        model.setHikeBPM(hikeID, bpm);
    }

    /**
     * Retrieves all of the hikes as an ArrayList of Adventures.
     * @return An ArrayList of Adventures of all the hikes.
     */
    public ArrayList<Adventure> getAllHikes() {
       return model.getAllHikes();
    }

    /**
     * Gets a specific adventure based on the id.
     * @param hikeID The id of the hike to search for.
     * @return The adventure based on the hike id.
     */
    public Adventure getSpecificHike(int hikeID) {
        return model.getSpecificHike(hikeID);
    }

    /**
     * Retrieves a HashMap of all of the backpack items based on the hike id.
     * @param hikeID The id of the hike to search for.
     * @return All of the backpack contents as a HashMap<String, boolean>
     */
    public HashMap<String, Boolean> getHikeBackpack(int hikeID) {
        return model.getHikeBackpack(hikeID);
    }

    /**
     * Updates all of the items in the backpack, based on the hike id.
     * @param hikeID The hike id to search for.
     * @param item The item to update.
     * @param checked The value of the item to update.
     * @return true if successful, else false.
     */
    public boolean updateBackpackItem(int hikeID, String item, boolean checked) {
        return model.updateBackpackItem(hikeID, item, checked);
    }

    /**
     * A function to add a reminder to a hike, based on the hike id.
     * @param hikeID The hike id to search for.
     * @param reminder The reminder to update.
     * @return true if successful, else false.
     */
    public boolean addReminderToHike(int hikeID, String reminder) {
        return model.addReminderToHike(hikeID, reminder);
    }

    /**
     * A function to get all of the hike's reminders, based on the hike id.
     * @param hikeID The hike id to search for.
     * @return An ArrayList of Strings representing the hike's reminders.
     */
    public ArrayList<String> getHikeReminders(int hikeID) {
        return model.getHikeReminders(hikeID);
    }

    /**
     * A function to get the previous hike locations.
     * @return An ArrayList of Strings to represent the previous hikes.
     */
    public ArrayList<String> getPreviousLocations() {
        return model.getPreviousLocations();
    }

    /**
     * A function to get all of the steps for all of the hikes.
     * @return An int representing the number of all steps for all hikes.
     */
    public int getStepsForAllHikes() {
        return model.getStepsForAllHikes();
    }

    /**
     * A function to get the average bpm of all hikes.
     * @return An int representing the average bpm of all hikes.
     */
    public int getBPMForAllHikes() {
        return model.getBPMForAllHikes();
    }
}
