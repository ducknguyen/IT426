package io.exporting;

/**
 * @author: Duck Nguyen
 * @date:   03/03/2018
 *
 * XMLExporter exports car parts from model to parts.xml file
 */

import io.IExporter;
import model.CarPart;
import model.PartsModel;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.Collection;

public class XMLExporter implements IExporter
{
    private String destination = "files/parts.xml";

    private DocumentBuilderFactory docFactory;
    private DocumentBuilder docBuilder;
    private Document partsDocument;
    private Element root;

    private Collection<CarPart> partsToExport;

    TransformerFactory transformerFactory;
    Transformer megatron;
    DOMSource source;
    StreamResult result;

    /**
     * Exports all CarPart objects in the application to a text file
     *
     * @param data - model data to write to file
     */
    @Override
    public void exportParts(PartsModel data)
    {
        try
        {
            docFactory = DocumentBuilderFactory.newInstance();
            docBuilder = docFactory.newDocumentBuilder();

            // root element
            partsDocument = docBuilder.newDocument();
            root = partsDocument.createElement("parts");
            partsDocument.appendChild(root);

            // get parts and translate to xml
            partsToExport = data.getParts();
            convertToXMLFormat();

            //wirte the content to xml file
            writeToXMLFile();
        }
        catch (ParserConfigurationException e)
        {
            e.printStackTrace();
        }
    }


// HELPER METHODS

    private void convertToXMLFormat()
    {
        for (CarPart part : partsToExport)
        {
            Element currentPart = partsDocument.createElement("part");
            root.appendChild(currentPart);

            Element currentPartID = createElement("id", part.getId());
            currentPart.appendChild(currentPartID);

            Element currentPartManufacturer = createElement("manufacturer", part.getManufacturer());
            currentPart.appendChild(currentPartManufacturer);

            Element currentPartPrice = createElement("listprice", Double.toString(part.getListPrice()));
            currentPart.appendChild(currentPartPrice);
        }
    }

    private Element createElement(String name, String text)
    {
        Element toBeAdded = partsDocument.createElement(name);
        toBeAdded.appendChild(partsDocument.createTextNode(text));

        return toBeAdded;
    }

    private void writeToXMLFile()
    {
        try
        {
            transformerFactory = TransformerFactory.newInstance();
            megatron = transformerFactory.newTransformer();
            source = new DOMSource(partsDocument);
            result = new StreamResult(new File(destination));

            // indenting for readability
            megatron.setOutputProperty(OutputKeys.INDENT, "yes");
            megatron.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

            megatron.transform(source, result);
        } catch (TransformerConfigurationException e)
        {
            e.printStackTrace();
        } catch (TransformerException e) {
            e.printStackTrace();
        }
    }
}