package strategies;

import rankings.Review;

import java.util.List;

public class WeightedStrategy implements IStrategy {

    @Override
    public int getScore(int year, List<Review> reviews) {
        int total = 0;
        for (Review review : reviews) {
            for (int i = 0; i < review.getKpis().length; i++) {
                if (review.getYear() == year) {
                    if (i == 1) { //team work
                        total += review.getKpis()[i] * 2;
                    } else if (i == 3) { //communication
                        total += review.getKpis()[i] * 3;
                    }
                    total += review.getKpis()[i];
                }
            }
        }
        return total;
    }
}
