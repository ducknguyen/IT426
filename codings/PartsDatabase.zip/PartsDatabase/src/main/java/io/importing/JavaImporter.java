package io.importing;

/**
 * @author: Duck Nguyen
 * @date:   03/03/2018
 *
 * JavaImporter imports car parts from parts.dat to model
 */

import io.IImporter;
import model.CarPart;
import model.PartsModel;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Collection;

public class JavaImporter implements IImporter
{
    private String destinationFile = "files/parts.dat";
    private ObjectInputStream reader;

    private Collection<CarPart> allParts;

    @Override
    public void importParts(PartsModel data)
    {
        try
        {
            reader = new ObjectInputStream(new FileInputStream(destinationFile));
            allParts = (Collection<CarPart>) reader.readObject();

            for (CarPart part : allParts)
            {
                data.addPart(part);
            }
            reader.close();

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
    }
}