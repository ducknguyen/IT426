package view;

/* File Name: HomeScreen.java
 * Author: Duck Nguyen
 * Date: 02/16/18
 * Description: view for application's home screen
 */

import controller.Controller;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;
import model.Adventure;

import java.time.LocalDate;
import java.util.ArrayList;

public class HomeScreen {
    private final int WIN_HEIGHT = 900;
    private final int TOTAL_ROWS = 10;
    private final int TOTAL_COLUMNS = 4;

    private Controller controller;
    private ArrayList<Adventure> hikes;

    private GridPane homeScene;
    private VBox profileArea;

    TextFlow heartRateStat, totalStepStat, locationVisitedStat;
    private Button newAdventureToggler, previousAdventureToggler;

    private VBox newAdventure;
    private ComboBox hikePicker;
    private DatePicker hikeDatePicker;
    private String selectedHike;
    private LocalDate selectedHikeDay;

    private ScrollPane previousAdventure;

    /**
     * Constructor for HomeScreen
     */
    public HomeScreen() {
        controller = new Controller();
        hikes = controller.getAllHikes();

        homeScene = new GridPane();
        constraintHomeScreenGrid();
        styleHomeScreen();

        buildProfileArea();
        buildStatArea();

        buildAdventureToggler();

        buildNewAdventureArea();
        buildPreviousAdventureArea();
    }

    /**
     * Getter to retrieve homescreen view
     *
     * @return homescreen view
     */
    public GridPane getHomeScreen() {
        return homeScene;
    }

//HOME SCENE
    private void constraintHomeScreenGrid() {
        for (int i = 0; i < TOTAL_COLUMNS; i++) {
            ColumnConstraints colConst = new ColumnConstraints(136);
            colConst.setHalignment(HPos.CENTER);
            homeScene.getColumnConstraints().add(colConst);
        }
    }

    private void styleHomeScreen() {
        homeScene.getStylesheets().add(this.getClass()
                .getClassLoader().getResource("css/home-screen.css").toExternalForm());
    }


//PROFILE AREA
    private void buildProfileArea() {
        profileArea = new VBox();

        ImageView joseProfilePic = createImageViewFromSource("images/jose.png", 100, 100);
        Label joseName = new Label("José José");

        profileArea.setId("profile-area");
        joseName.setId("jose-name");

        profileArea.getChildren().addAll(joseProfilePic, joseName);

        homeScene.setMargin(profileArea, new Insets(6, 0, 35, 0));
        homeScene.add(profileArea, 0, 1, TOTAL_COLUMNS, 1);
    }


//STATS AREA
    private void buildStatArea() {
        heartRateStat = buildStatContainer(Integer.toString(controller.getBPMForAllHikes()), "BPM");
        homeScene.add(heartRateStat, 0, 4);

        totalStepStat = buildStatContainer(Integer.toString(controller.getStepsForAllHikes()), "STEPS");
        totalStepStat.setId("total-step-stat");
        homeScene.add(totalStepStat, 1, 4, 2, 1);

        locationVisitedStat = buildStatContainer(Integer.toString(hikes.size()), "HIKES");
        homeScene.add(locationVisitedStat, 3, 4);
    }

    private TextFlow buildStatContainer(String stat, String unit) {
        TextFlow statToDisplay = new TextFlow();
        statToDisplay.setTextAlignment(TextAlignment.CENTER);

        Label statNumber = new Label(stat);
        statNumber.getStyleClass().add("stat-number");

        Text statUnit = new Text("\n" + unit);
        statUnit.getStyleClass().add("stat-unit");

        statToDisplay.getChildren().addAll(statNumber, statUnit);
        return statToDisplay;
    }


//ADVENTURE TOGGLER BUTTONS
    private void buildAdventureToggler() {
        newAdventureToggler = new Button("NEW HIKE");
        previousAdventureToggler = new Button("HIKE LOG");

        styleAdventureToggleButton();

        newAdventureToggler.setOnAction(e -> toggleAdventureAreaVisibility(e));
        previousAdventureToggler.setOnAction(e -> toggleAdventureAreaVisibility(e));

        homeScene.add(newAdventureToggler, 0, 5, TOTAL_COLUMNS / 2, 1);
        homeScene.add(previousAdventureToggler, 2, 5, TOTAL_COLUMNS / 2, 1);
    }

    private void toggleAdventureAreaVisibility(ActionEvent e) {
        String current = ((Button) e.getSource()).getText();
        if (current == "NEW HIKE") {
            previousAdventure.setVisible(false);
            previousAdventure.managedProperty().bind(previousAdventure.visibleProperty());
            newAdventure.setVisible(true);
        } else {
            newAdventure.setVisible(false);
            newAdventure.managedProperty().bind(newAdventure.visibleProperty());
            previousAdventure.setVisible(true);
        }
    }

    private void styleAdventureToggleButton() {
        newAdventureToggler.getStyleClass().add("adventure-toggler");
        previousAdventureToggler.getStyleClass().add("adventure-toggler");

        newAdventureToggler.setId("new-adventure-toggler");
        previousAdventureToggler.setId("previous-adventure-toggler");

        homeScene.setMargin(newAdventureToggler, new Insets(25, 0, 0, 0));
        homeScene.setMargin(previousAdventureToggler, new Insets(25, 0, 0, 0));
    }


//NEW ADVENTURE AREA
    private void buildNewAdventureArea() {
        newAdventure = new VBox();

        hikePicker = new ComboBox();
        buildHikePicker();

        hikeDatePicker = new DatePicker();
        buildHikeDatePicker();

        Button startNewHike = new Button("ADVENTURE TIME");
        startNewHike.setOnAction(e -> processStartNewHike(e));
        startNewHike.setId("start-new-hike");

        newAdventure.getChildren().addAll(hikePicker, hikeDatePicker, startNewHike);
        styleNewAdventureArea();

        homeScene.add(newAdventure, 0, 6, TOTAL_COLUMNS, TOTAL_ROWS);
    }

    private void buildHikePicker() {
        ArrayList<String> locations = controller.getPreviousLocations();
        // test string for location picker
        hikePicker.setPromptText("Enter a location");
        hikePicker.setEditable(true);
        hikePicker.setVisibleRowCount(5);

        for (String location : locations)
        {
            hikePicker.getItems().add(location);
        }

        hikePicker.valueProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                selectedHike = newValue;
            }
        });
    }

    private void buildHikeDatePicker() {
        hikeDatePicker.setValue(LocalDate.now());
    }

    private void processStartNewHike(ActionEvent e) {
        selectedHikeDay = hikeDatePicker.getValue();
        String test = String.valueOf(hikeDatePicker.getValue());
        controller.createNewHike(selectedHike, test);
        int hikeID = controller.getLastInsertedRow();
        controller.changeScene(new HikeInfo(hikeID).getHikeInfo());
    }

    private void styleNewAdventureArea() {
        newAdventure.setPrefHeight(WIN_HEIGHT);
        newAdventure.getStyleClass().add("adventure");
        newAdventure.getStyleClass().add("new-adventure");
    }

//OLD ADVENTURE AREA
    private void buildPreviousAdventureArea() {
        previousAdventure = new ScrollPane();
        previousAdventure.setVisible(false);

        VBox innerContent = new VBox();
        innerContent.setId("inner-content");
        for (Adventure hike : hikes) {
            Label hikeTitle = new Label(hike.getLocation());
            hikeTitle.setId("hike-title");

            Label hikeDate = new Label(hike.getWhen());
            hikeTitle.getStyleClass().add("logHikeDate");

            VBox logRow = new VBox();
            logRow.getStyleClass().add("logRow");
            logRow.getChildren().addAll(hikeTitle, hikeDate);

            logRow.addEventFilter(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>()
            {
                @Override
                public void handle(MouseEvent event)
                {
                    controller.changeScene(new HikeInfo(hike.getID()).getHikeInfo());
                }
            });
            innerContent.getChildren().add(logRow);
        }

        previousAdventure.setContent(innerContent);
        stylePreviousAdventureArea();
        homeScene.add(previousAdventure, 0, 6, TOTAL_COLUMNS, TOTAL_ROWS);
    }

    private void stylePreviousAdventureArea() {
        previousAdventure.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        previousAdventure.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);

        previousAdventure.setFitToHeight(true);
        previousAdventure.setFitToWidth(true);

        previousAdventure.getStyleClass().add("adventure");
        previousAdventure.getStyleClass().add("previous-adventure");
    }


//HELPER FOR CREATING IMAGEVIEWS
    private ImageView createImageViewFromSource(String src, int width, int height) {
        Image imageSource = new Image(src, width, height, false, false);
        return new ImageView(imageSource);
    }
}