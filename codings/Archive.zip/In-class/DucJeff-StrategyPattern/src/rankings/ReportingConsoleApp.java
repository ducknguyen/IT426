package rankings;

import strategies.IStrategy;
import strategies.SelectiveStrategy;
import strategies.TotalStrategy;
import strategies.WeightedStrategy;

import java.util.Scanner;

public class ReportingConsoleApp
{
    public static void main(String[] args)
    {
        IStrategy selectedStrategy;
        RankingsCalculator calculator;
        Scanner scanner = new Scanner(System.in);
        /*
            1: display a welcome message for the user
            2: Prompt the user for a strategy: TotalStrategy, WeightedStrategy or SelectiveStrategy.
            3: Create the requested strategy object
            4: Create a RankingsCalculator object and print out the reviews using printRankings()
         */
        System.out.println("Welcome to the Employee Ranking Application");
        System.out.println("*******************************************");
        System.out.println("Please select a strategy");
        System.out.println("1. Total");
        System.out.println("2. Weighted");
        System.out.println("3. Selective");

        int i = scanner.nextInt();

        System.out.println("Please enter a year: ");
        int year = scanner.nextInt();

        if(i==1){
            selectedStrategy = new TotalStrategy();
            calculator = new RankingsCalculator();
            calculator.printRankings(selectedStrategy, year);

        }
        else if(i==2){
            selectedStrategy = new WeightedStrategy();
            calculator = new RankingsCalculator();
            calculator.printRankings(selectedStrategy, year);
        }
        else if(i==3){
            selectedStrategy = new SelectiveStrategy();
            calculator = new RankingsCalculator();
            calculator.printRankings(selectedStrategy, year);
        }


    }
}
