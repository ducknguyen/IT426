package model;

import java.io.Serializable;
import java.util.Date;

/**
 * A class used to represent an adventure in the Jose The Explorer app.
 */
public class Adventure implements Serializable {

    private String location;
    private String when;
    private int steps;
    private int bpm;
    private int hikeID;


    public Adventure(int hikeID, String location, String when) {
        this.hikeID = hikeID;
        this.location = location;
        this.when = when;
    }

    public void setSteps(int steps) {
        this.steps = steps;
    }

    public void setBPM(int bpm) {
        this.bpm = bpm;
    }

    public int getID() {
        return hikeID;
    }

    public int getSteps() {
        return steps;
    }

    public int getBPM() {
        return bpm;
    }

    /**
     * Gets the location of the adventure.
     *
     * @return Returns the location of the adventure.
     */
    public String getLocation() {
        return location;
    }

    /**
     * Sets the location of the hike.
     *
     * @param location The new location to set.
     */
    public void setLocation(String location) {
        this.location = location;
    }

    /**
     * Gets the date of the hike.
     *
     * @return the date of the hike.
     */
    public String getWhen() {
        return when;
    }

    /**
     * Sets the date of the hike.
     *
     * @param when the date to set to.
     */
    public void setWhen(String when) {
        this.when = when;
    }

}