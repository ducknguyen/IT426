package drawing;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public interface IShape
{

// METHOD CHAININGS

    /**
     * Setting the thickness of shape's stroke
     *
     * @param value - 1-10 of thickness level
     * @return Shape with selected stroke thickness
     */
    public IShape setThickness(double value);

    /**
     * Setting the color of shape
     *
     * @param value - selected color
     * @return Shape with selected color value
     */
    public IShape setColor(Color value);

    /**
     * Toggle filling shape with color
     *
     * @param value - selected fill option
     * @return Shape with selected fill option
     */
    public IShape setFilled(boolean value);



// GETTER METHODS

    /**
     * Retrieve selected x coordinate to draw on canvas
     *
     * @return value of x
     */
    public double getXCoordinate();

    /**
     * Retrieve selected y coordinate to draw on canvas
     *
     * @return value of y
     */
    public double getYCoordinate();

    /**
     * Retrieve selected thickness for the shape
     *
     * @return thickness level 1-10
     */
    public double getThickness();

    /**
     * Retrieve selected color for the shape
     *
     * @return value of color
     */
    public Color getColor();

    /**
     * Retrieve selected shape color filling option
     *
     * @return true if filled, false otherwise
     */
    public boolean getFilled();



// DRAW SHAPE

    /**
     * Draw shape on canvas with GraphicsContext
     *
     * @param graphics to draw on canvas
     */
    public void drawShape(GraphicsContext graphics);
}
