package launchers;

/**
 * @author: Duck Nguyen
 * @date: 03/21/2018
 *
 * Launcher launches our doodle pad application
 */

import javafx.application.Application;
import ui.DoodlePadGUI;

public class Launcher
{
    public static void main(String[] args)
    {
        Application.launch(DoodlePadGUI.class, args);
    }
}


