package io.importing;

import io.IImporter;
import model.CarPart;
import model.PartsModel;

import java.io.BufferedReader;
import java.io.FileReader;

public class CSVImporter implements IImporter
{
    private String destination = "files/parts.csv";
    private BufferedReader reader;
    private String line;

    /**
     * Imports all CarPart objects from a text file to the application
     *
     * @param data - model data to read from file
     */
    @Override
    public void importParts(PartsModel data)
    {
        try {
            reader = new BufferedReader(new FileReader(destination));
            // skip header
            reader.readLine();

            while ( (line = reader.readLine()) != null)
            {
                String[] lineContents = line.split(",");
                if (line.length() > 0)
                {
                    // [0] = id, [1] = manufacturer, [2] = listprice
                    data.addPart(new CarPart(lineContents[0], lineContents[1],
                            Double.parseDouble(lineContents[2])));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}