package view;

import controller.Controller;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import model.Adventure;

import java.util.ArrayList;
import java.util.HashMap;


public class HikeInfo
{

    Controller c = new Controller();
    int hikeID;
    Adventure hike;
    ArrayList<String> reminders;
    HashMap<String, Boolean> backpack;

    private final int TOTAL_COLUMNS = 4;

    private GridPane hikeInfoScreen;

    private VBox hikeDetailsArea;
    private Text hikeHeader;
    private Label stepsTaken;
    private Label averageHeartRate;
    private String steps = "";
    private String heartrate = "";
    private TextField stepsInput;
    private TextField bpmInput;
    private Button saveStats;

    private VBox backpackArea;
    private Text backpackHeader;

    private VBox reminderArea;
    private VBox reminderAreaContents;
    private Text reminderHeader;
    private int reminderCounter = 0;

    TextField newReminderItem;
    Button addNewReminderitem;



    /**
     * Constructor for HikeInfo
     */
    public HikeInfo(int hikeID)
    {
        this.hikeID = hikeID;
        hike = c.getSpecificHike(hikeID);
        reminders = c.getHikeReminders(hikeID);
        backpack = c.getHikeBackpack(hikeID);

        //HIKE INFO SCREEN
        hikeInfoScreen = new GridPane();
        constraintHomeScreenGrid();
        styleHikeInfo();

        //HIKE DETAIL AREA
        hikeDetailsArea = new VBox();
        buildHikeDetailsArea();

        //BACKPACK ITEMS AREA
        backpackArea = new VBox();
        buildBackPackArea();

        //REMINDER AREA
        reminderArea = new VBox();
        buildReminderItemsArea();
    }

    //HIKE INFO SCREEN
    private void constraintHomeScreenGrid()
    {
        for (int i=0; i < TOTAL_COLUMNS; i++)
        {
            ColumnConstraints colConst = new ColumnConstraints(136);
            hikeInfoScreen.getColumnConstraints().add(colConst);
        }
    }

    private void styleHikeInfo()
    {
        hikeInfoScreen.getStylesheets().add(this.getClass()
                .getClassLoader().getResource("css/hike-info-screen.css").toExternalForm());
    }

    //HIKE DETAILS AREA
    private void buildHikeDetailsArea()
    {
        hikeHeader = new Text(hike.getLocation());
        Text hikeDate = new Text("Date: " + hike.getWhen());

        stepsTaken = new Label("Total Steps:");
        stepsInput = new TextField("" + hike.getSteps());

        averageHeartRate = new Label("Heart Rate:");
        bpmInput = new TextField("" + hike.getBPM());

        saveStats = new Button("Save");
        saveStats.setOnAction(e -> processSaveInput(e));

        styleHikeDetailArea();

        hikeDetailsArea.getChildren().addAll(hikeHeader, hikeDate, stepsTaken, stepsInput,
                averageHeartRate, bpmInput, saveStats);
        hikeInfoScreen.add(hikeDetailsArea,0,0,3,1);
    }

    private void processSaveInput(ActionEvent e)
    {
        steps = stepsInput.getText();
        heartrate = bpmInput.getText();
        int checkStepInput = steps.length();
        int checkHearRateInput = heartrate.length();

        if (checkHearRateInput != 0 && checkStepInput != 0)
        {
            setNewInformation(steps, heartrate);
            c.setHikeSteps(hikeID, Integer.parseInt(steps));
            c.setHikeBPM(hikeID, Integer.parseInt(heartrate));
        }
        else
        {
            if (checkStepInput == 0)
            {
                stepsInput.setText("Please enter your total steps");
            }
            if (checkHearRateInput == 0)
            {
                bpmInput.setText("Please enter your hear rate");
            }
        }
    }
    private void setNewInformation(String steps, String heartrate)
    {
        stepsInput.setVisible(false);
        stepsInput.managedProperty().bind(stepsInput.visibleProperty());
        stepsTaken.setText("Total Steps: " + steps);

        bpmInput.setVisible(false);
        bpmInput.managedProperty().bind(stepsInput.visibleProperty());
        averageHeartRate.setText("Heart Rate: " + heartrate);
    }

    private void styleHikeDetailArea()
    {
        hikeDetailsArea.getStyleClass().add("hike-details-area");
        hikeHeader.setId("hike-title");
    }

    //BACKPACK AREA
    private void buildBackPackArea()
    {
        Button returnToHomeButton = new Button("X");
        returnToHomeButton.getStyleClass().add("returnToHomeButton");
        returnToHomeButton.setOnAction(e -> processReturnHome(e));
        backpackArea.getChildren().add(returnToHomeButton);

        backpackHeader = new Text("Hike backpack");
        backpackHeader.setId("backpack-header");
        backpackArea.getChildren().add(backpackHeader);

        for(String item : backpack.keySet())
        {
            String properItem = capitalizeText(item);
            CheckBox newCheckBox = new CheckBox(properItem);
            newCheckBox.setSelected(backpack.get(item));
            newCheckBox.selectedProperty().addListener(new ChangeListener<Boolean>()
            {
                @Override
                public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue)
                {
                    c.updateBackpackItem(hikeID, item, newValue);
                }
            });
            backpackArea.getChildren().add(newCheckBox);
        }
        styleBackpackArea();
        hikeInfoScreen.add(backpackArea,3,0,1,1);
    }

    private void styleBackpackArea()
    {
        backpackArea.getStyleClass().add("backpack-area");
    }

    //REMINDER ITEMS AREA
    private void buildReminderItemsArea()
    {
        reminderArea.getStyleClass().add("reminder-area");

        reminderHeader = new Text("Your Reminders");
        reminderHeader.setId("reminder-header");

        reminderAreaContents = new VBox();
        for (String reminder : reminders)
        {
            reminderCounter++;
            Text newReminder = new Text(Integer.toString(reminderCounter) + ". " + reminder);
            newReminder.getStyleClass().add("reminderLabel");
            reminderAreaContents.getChildren().add(newReminder);
        }

        newReminderItem = new TextField();
        newReminderItem.setPromptText("Enter a new reminder for this hike");

        addNewReminderitem = new Button("ADD NEW REMINDER");
        addNewReminderitem.setOnAction(e -> processNewItem(e));

        reminderArea.getChildren().addAll(reminderHeader, reminderAreaContents,
                newReminderItem,addNewReminderitem);
        hikeInfoScreen.add(reminderArea,0,4,TOTAL_COLUMNS,1);
    }

    private void processNewItem(ActionEvent e)
    {
        String reminderToProcess = newReminderItem.getText();

        // add new reminder if the reminder is not empty
        if (reminderToProcess.length() != 0)
        {
            reminderCounter++;
            Text newReminder = new Text(Integer.toString(reminderCounter) + ". " + reminderToProcess);
            newReminder.getStyleClass().add("reminderLabel");

            reminderAreaContents.getChildren().add(newReminder);
            c.addReminderToHike(hikeID, reminderToProcess);

            newReminderItem.setText("");
        }
    }

    private void processReturnHome(ActionEvent e) {
        c.changeScene(new HomeScreen().getHomeScreen());
    }


    /**
     * Retrieve HikeInfo view
     * @return HikeInfo view
     */
    public GridPane getHikeInfo()
    {
        return hikeInfoScreen;
    }

    /**
     * Helper method to make the operation of first-letter-capitalization more
     * human readable in the code.
     * @param text String to be capitalized
     * @return a first-letter-capitalized string
     */
    private String capitalizeText(String text) {
        return text.substring(0,1).toUpperCase() + text.substring(1);
    }
}
