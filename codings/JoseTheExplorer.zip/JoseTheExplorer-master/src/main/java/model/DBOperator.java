package model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * A class used to represent the database operations handler.
 */
public class DBOperator {


// FIELDS, CONSTANTS, AND OBJECTS


    private final String URL = "jdbc:sqlite:data/data.db";
    private Connection db = null;


// CONSTRUCTOR(S)


    /**
     * Establishes a connection with the database and returns an instance of
     * this DBOperator class.
     */
    public DBOperator() {
        // Empty Constructor
    }


// METHODS - SQL DATA RETRIEVAL

    /**
     * Retrieves all of the hikes as an ArrayList of Adventures.
     * @return an ArrayList of all the hikes as Adventures.
     */
    public ArrayList<Adventure> getAllHikes() {
        establishConnection();
        ArrayList<Adventure> hikes = new ArrayList<>();
        String sql = "SELECT * FROM hikes";
        ResultSet results = runDatabaseQuery(sql);

        try {
            while (results.next()) {
                int hikeID = results.getInt("id");
                String location = results.getString("location");
                String date = results.getString("date");
                Adventure newHike = new Adventure(hikeID, location, date);
                newHike.setSteps(results.getInt("steps"));
                newHike.setBPM(results.getInt("bpm"));
                hikes.add(newHike);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        closeConnection();
        return hikes;
    }

    /**
     * A function to retrieve adventures by a hike ID.
     * @param hikeID the hike id to search by.
     * @return the Adventure that we are searching for.
     */
    public Adventure getSpecificHike(int hikeID) {
        establishConnection();
        Adventure hike = null;
        String sql = "SELECT * FROM hikes WHERE id=" + hikeID + ";";
        ResultSet results = runDatabaseQuery(sql);

        try {
            String location = results.getString("location");
            String date = results.getString("date");
            hike = new Adventure(hikeID, location, date);
            hike.setSteps(results.getInt("steps"));
            hike.setBPM(results.getInt("bpm"));
        } catch (SQLException e) {
            e.printStackTrace();
        }

        closeConnection();
        return hike;
    }

    /**
     * A function to get the all of the items in the backpack for a specific adventure, by ID.
     * @param hikeID The id to search for backpack contents of.
     * @return The backpack contents as a HashMap.
     */
    public HashMap<String, Boolean> getHikeBackpack(int hikeID) {
        establishConnection();
        HashMap<String, Boolean> backpack = new HashMap<>();
        String[] dbColumns = {"food", "water", "compass", "flashlight", "binoculars"};
        String sql = "SELECT food,water,compass,flashlight,binoculars FROM backpacks WHERE hike_id=" + hikeID + ";";
        ResultSet results = runDatabaseQuery(sql);

        try {
            for (int i = 0; i < dbColumns.length; i++) {
                String column = dbColumns[i];
                boolean checked = results.getInt(dbColumns[i]) == 1;
                backpack.put(column, checked);
            }
        } catch (SQLException e) {
            System.out.println("Error building backpack: " + e.getMessage());
            e.printStackTrace();
        }

        closeConnection();
        return backpack;
    }

    /**
     * A function to retireve the steps taken for all hikes.
     * @return The integer of the the amount of steps taken for all hikes.
     */
    public int getStepsForAllHikes() {
        establishConnection();
        int totalSteps = 0;
        String sql = "SELECT steps FROM hikes";
        ResultSet results = runDatabaseQuery(sql);

        try {
            while (results.next()) {
                int current = results.getInt("steps");
                totalSteps += current;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        closeConnection();
        return totalSteps;
    }

    /**
     * A function to get the total BPM of all hikes.
     * @return the heartrate in BPM of all hikes.
     */
    public int getBPMForAllHikes() {
        establishConnection();
        int totalBPM = 0;
        int bpmCount = 0;
        String sql = "SELECT bpm FROM hikes";
        ResultSet results = runDatabaseQuery(sql);

        try {
            while (results.next()) {
                int current = results.getInt("bpm");
                totalBPM += current;
                if (current > 0) bpmCount++;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        closeConnection();
        if (bpmCount > 0) return totalBPM / bpmCount;
        return 0;
    }

    /**
     * A function to retrieve the previous location.
     * @return An ArrayList of String of previous hike locations.
     */
    public ArrayList<String> getPreviousLocations() {
        establishConnection();
        ArrayList<String> locations = new ArrayList<>();
        String sql = "SELECT location FROM hikes;";
        ResultSet results = runDatabaseQuery(sql);

        try {
            while (results.next()) {
                String currentLocation = results.getString("location");
                System.out.print(currentLocation + ": ");
                if (!locations.contains(currentLocation)) {
                    locations.add(currentLocation);
                    System.out.println("ADDED");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        closeConnection();
        return locations;
    }

    /**
     * A function to retireve all of a hike's reminders, by hike id.
     * @param hikeID The ID to search for.
     * @return The hike reminders as an ArrayList<String>
     */
    public ArrayList<String> getHikeReminders(int hikeID) {
        establishConnection();
        ArrayList<String> reminders = new ArrayList<>();
        String sql = "SELECT reminder FROM reminders WHERE hike_id=" + hikeID + ";";
        ResultSet results = runDatabaseQuery(sql);

        try {
            while (results.next()) {
                reminders.add(results.getString("reminder"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        closeConnection();
        return reminders;
    }

    public int getLastInsertedRow() {
        establishConnection();
        int rowID = -1;
        String sql = "SELECT last_insert_rowID() AS lastID FROM hikes;";

        try {
            rowID = runDatabaseQuery(sql).getInt("lastID");
        } catch (SQLException e) {
            System.out.println("Error retrieving last row ID: " + e.getMessage());
            System.out.println("SQL: " + sql);
            e.printStackTrace();
        }

        closeConnection();
        return rowID;
    }


// METHODS - SQL DATA INSERTION

    /**
     * A function to create a new adventure/hike.
     * @param location The location of the new hike.
     * @param date The date of the new hike.
     * @return True if successful, false if failed.
     */
    public boolean createNewHike(String location, String date) {
        establishConnection();
        String sql = "INSERT INTO hikes (location,date) VALUES " +
                "('" + location + "', '" + date + "');";

        if (runDatabaseInsertion(sql)) {
            closeConnection();
            return createBackpackTable(getLastInsertedRow());
        }

        closeConnection();
        return false;
    }

    private boolean createBackpackTable(int hikeID) {
        establishConnection();
        String sql = "INSERT INTO backpacks (hike_id) VALUES (" + hikeID + ");";
        boolean results = runDatabaseInsertion(sql);
        closeConnection();
        return results;
    }

    /**
     * A function to add a reminder to a hike, by hike id.
     * @param hikeID The hike id to add the reminder to.
     * @param reminder The reminder you want to add.
     * @return true if successful, false if failed.
     */
    public boolean addReminderToHike(int hikeID, String reminder) {
        establishConnection();
        String sql = "INSERT INTO reminders (hike_id, reminder) VALUES (" + hikeID + ", '" + reminder + "');";
        boolean results = runDatabaseInsertion(sql);
        closeConnection();
        return results;
    }


// METHODS - SQL DATA UPDATES

    /**
     * A function to add a steps to a hike, by hike id.
     * @param hikeID The hike id to add the reminder to.
     * @param steps The steps you want to add.
     * @return true if successful, false if failed.
     */
    public boolean setHikeSteps(int hikeID, int steps) {
        establishConnection();
        String sql = "UPDATE hikes SET steps = " + steps + " WHERE id=" + hikeID + ";";
        boolean results = runDatabaseInsertion(sql);
        closeConnection();
        return results;
    }
    /**
     * A function to add a bpm to a hike, by hike id.
     * @param hikeID The hike id to add the reminder to.
     * @param bpm The bpm you want to add.
     * @return true if successful, false if failed.
     */
    public boolean setHikeBPM(int hikeID, int bpm) {
        establishConnection();
        String sql = "UPDATE hikes SET bpm = " + bpm + " WHERE id=" + hikeID + ";";
        boolean results = runDatabaseInsertion(sql);
        closeConnection();
        return results;
    }
    /**
     * A function to add a backpack item to a hike, by hike id.
     * @param hikeID The hike id to add the reminder to.
     * @param item The backpack item you want to add.
     * @param checked If the backpack item is packed true, if not, false.
     * @return true if successful, false if failed.
     */
    public boolean updateBackpackItem(int hikeID, String item, boolean checked) {
        establishConnection();
        int checkValue = checked ? 1 : 0;
        String sql = "UPDATE backpacks SET " + item + " = " + checkValue + " where hike_id=" + hikeID + ";";
        boolean results = runDatabaseInsertion(sql);
        closeConnection();
        return results;
    }


// METHODS - HELPERS


    private void establishConnection() {
        try  {
            db = DriverManager.getConnection(URL);
            db.setAutoCommit(true);
        } catch (SQLException e) {
            System.out.println("Error accessing database :" + e.getMessage());
        }
    }

    private void closeConnection() {
        try {
            db.close();
        } catch (SQLException e) {
            System.out.println("Error closing database connection: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private boolean runDatabaseInsertion(String sql) {
        try {
            Statement stmt = db.createStatement();
            stmt.executeUpdate(sql);
            stmt.close();
            return true;
        } catch (SQLException e) {
            System.out.println("Error inserting into database: " + e.getMessage());
            System.out.println("SQL: " + sql);
            e.printStackTrace();
            return false;
        }
    }

    private ResultSet runDatabaseQuery(String sql) {
        try {
            Statement stmt = db.createStatement();
            ResultSet results = stmt.executeQuery(sql);
            return results;
        } catch (SQLException e) {
            System.out.println("Error running query: " + e.getMessage());
            System.out.println("SQL: " + sql);
            e.printStackTrace();
        }
        return null;
    }

}
