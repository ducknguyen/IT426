package shapes;

import javafx.scene.paint.Color;

public class Star extends Shape
{
    private double[] xPoints;
    private double[] yPoints;

    /**
     * Constructor for a Star shape object
     * @param x - x coordinate on canvas
     * @param y - y coordinate on canvas
     * @param xPoints - x coordinates to draw star
     * @param yPoints - y coordinates to draw star
     * @param thickness - selected thickness
     * @param color - selected color
     */
    public Star(double x, double y, double[] xPoints, double[] yPoints, double thickness, Color color)
    {
        super(x,y,thickness,color);
        this.xPoints = xPoints;
        this.yPoints = yPoints;
    }

    public double[] getXPoints()
    {
        return xPoints;
    }

    public double[] getyPoints()
    {
        return yPoints;
    }

    public String toString()
    {
        return "Star [xPoints=" + xPoints + ", ----- yPoints=" + yPoints + " " + super.toString() + "]";
    }
}
