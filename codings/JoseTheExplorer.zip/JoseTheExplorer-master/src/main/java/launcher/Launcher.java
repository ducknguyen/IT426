package launcher;

import javafx.application.Application;
import view.LoadingScreen;

import java.util.Locale;

public class Launcher
{
    public static void main(String[] args)
    {
        Locale.setDefault(Locale.US);
        Application.launch(LoadingScreen.class, args);
    }
}
