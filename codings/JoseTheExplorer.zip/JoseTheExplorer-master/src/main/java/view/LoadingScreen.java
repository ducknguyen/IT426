package view;

/* File Name: LoadingScreen.java
 * Author: Duck Nguyen
 * Date: 02/10/18
 * Description: view for application's loading screen
 */

import controller.Controller;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.FileNotFoundException;

public class LoadingScreen extends Application
{
    private final int WIN_WIDTH = 552;
    private final int WIN_HEIGHT = 900;
    private final int LOADING_SCREEN_TIME = 4000;

    Controller controller = new Controller();


    //save our stage
    private Stage stage;

    private VBox loadingScreen;
    private HomeScreen homeScreen;
    private HikeInfo hikeInfo;

    @Override
    public void start(Stage stage) throws Exception
    {
        this.stage = stage;
        controller.setStage(this.stage);
        stage.setTitle("JOSE THE EXPLORER");
        stage.setScene(buildLoadingScene());

        KeyFrame frame = new KeyFrame(Duration.millis(LOADING_SCREEN_TIME), new EventHandler<ActionEvent>()
        {
            @Override
            public void handle(ActionEvent event)
            {
                //route to home uncommented to use
                homeScreen = new HomeScreen();
                stage.getScene().setRoot(homeScreen.getHomeScreen());

//                //route to info
//                hikeInfo = new HikeInfo();
//                stage.getScene().setRoot(hikeInfo.getHikeInfo());
            }
        });

        Timeline waitAnimation = new Timeline(frame);
        waitAnimation.play();
        stage.show();
    }

    private Scene buildLoadingScene() throws FileNotFoundException
    {
        loadingScreen = new VBox();
        ImageView loadingLogo = createImageViewFromSource("images/logo.png",300,180);
        Text loadingMessage = new Text("Preparing your hike information...");

        loadingScreen.getChildren().addAll(loadingLogo,loadingMessage);
        styleLoadingScene();

        return new Scene(loadingScreen, WIN_WIDTH,WIN_HEIGHT);
    }

    private void styleLoadingScene()
    {
        loadingScreen.getStylesheets().add(this.getClass()
                .getClassLoader().getResource("css/loading-screen.css").toExternalForm());
    }

    private ImageView createImageViewFromSource(String src, int width, int height)
    {
        Image imageSource = new Image(src, width, height,false,false);
        return new ImageView(imageSource);
    }
}