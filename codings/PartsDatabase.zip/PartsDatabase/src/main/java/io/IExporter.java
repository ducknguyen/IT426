package io;

import model.PartsModel;

public interface IExporter
{
    /**
     * Exports all CarPart objects in the application to a text file
     *
     * @param data - model data to write to file
     */
    public void exportParts(PartsModel data);
}
